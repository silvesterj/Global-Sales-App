BugTrap for Win32 & .NET Release 1.3.3718.38316
____________________________________________________________

BugTrap substitutes default error handler and gathers detailed
information about the problem and system environment.

See detailed description in "BugTrap Developer's Guide".
Find additional support at http://www.intellesoft.net/