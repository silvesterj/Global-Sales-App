This folder includes all BugTrap servers selected during installation.

You may find here the following subfolders:
------------------------------------------------------------------------------------
BugTrapServer     - BugTrap Server implemented as Windows service.
JBugTrapServer    - BugTrap Server implemented as Java application.
BugTrapWebServer  - BugTrap Server implemented as ASP.NET Web application.

Please see "BugTrap Developer's Guide" for additional information about BugTrap servers.