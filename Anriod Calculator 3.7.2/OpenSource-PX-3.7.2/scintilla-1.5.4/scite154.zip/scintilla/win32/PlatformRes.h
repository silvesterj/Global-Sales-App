// Scintilla source code edit control
/** @file PlatformRes.h
 ** Defines IDs of resources used by Scintilla on Windows platform.
 **/
// Copyright 1998-2001 by Neil Hodgson <neilh@scintilla.org>
// The License.txt file describes the conditions under which this software may be distributed.

#define IDC_MARGIN                 400
