/** Automatically generated file. DO NOT MODIFY */
package com.productxpress.pxtestapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}